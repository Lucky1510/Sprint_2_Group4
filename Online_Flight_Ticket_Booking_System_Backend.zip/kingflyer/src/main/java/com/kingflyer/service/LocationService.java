package com.kingflyer.service;

import java.util.Set;

import com.kingflyer.model.Location;

public interface LocationService {
	public Set<Location> addLocation(Set<Location> location);
}
