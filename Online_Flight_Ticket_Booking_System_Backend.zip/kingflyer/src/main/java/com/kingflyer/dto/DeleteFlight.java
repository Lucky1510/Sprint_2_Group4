package com.kingflyer.dto;

public class DeleteFlight {
public String userName;
public String password;
public int flightId;
}
