package com.kingflyer.dto;

public class UserLogin {
	public String tempUserName;
	public String tempPassword;

}
