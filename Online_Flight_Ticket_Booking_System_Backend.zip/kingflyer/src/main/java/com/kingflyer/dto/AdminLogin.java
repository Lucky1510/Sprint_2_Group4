package com.kingflyer.dto;

public class AdminLogin {
	public String userName;
	public String password;

}
